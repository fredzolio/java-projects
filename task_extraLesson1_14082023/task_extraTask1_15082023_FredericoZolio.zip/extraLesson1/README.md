## Nota

Professora, espero que você esteja bem!

Por se tratar de uma atividade extra, irei tentar escrever o código em inglês, para ir me ambientando e acostumando com a ideia.
Espero que você não se importe.